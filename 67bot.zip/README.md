# Discord Moderation & Ticket Bot

## Setup

1. `npm install` (already done if you're reading this after scaffolding)
2. Fill in `.env`:
   - `DISCORD_TOKEN` — from the [Discord Developer Portal](https://discord.com/developers/applications) → your app → Bot → Reset/Copy Token
   - `STAFF_ROLE_ID` — the role that can see ticket channels
   - `TICKET_PANEL_CHANNEL_ID` — channel where the ticket panel embed lives (informational only, not enforced by the bot)
   - `TICKETS_CATEGORY_ID` — category new ticket channels are created under
3. In the Developer Portal, enable these under Bot → Privileged Gateway Intents:
   - Server Members Intent
   - Message Content Intent
4. Invite the bot with these scopes/permissions (OAuth2 → URL Generator):
   - Scopes: `bot`
   - Permissions: Manage Channels, Manage Roles, Kick Members, Ban Members, Moderate Members, Send Messages, Read Message History, View Channels
5. Run it:

```bash
npm start
```

## Commands (prefix `,`)

| Command | Description |
|---|---|
| `,help` | List commands |
| `,warn @user [reason]` | Warn a user (in-memory, resets on restart) |
| `,warnings @user` | View a user's warnings |
| `,kick @user [reason]` | Kick a user |
| `,ban @user [reason]` | Ban a user |
| `,unban <user_id>` | Unban a user |
| `,mute @user <5m\|1h\|1d>` | Timeout a user |
| `,unmute @user` | Remove timeout |
| `,panel` | Post the ticket panel (Buy/Sell/Support buttons) — admin only |
| `,close` | Close the current ticket channel |

## Notes

- Warnings and open tickets are stored in memory (`Map`) — they reset when the bot restarts. For persistence, swap these for a real database (SQLite/Postgres/etc).
- The bot's own role must sit above any role it needs to kick/ban/timeout, and it needs Manage Channels permission in the tickets category to create ticket channels.
